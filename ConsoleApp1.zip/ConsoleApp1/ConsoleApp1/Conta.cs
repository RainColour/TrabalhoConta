﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Conta
    {
        public long Numero { get; private set; }
        public decimal Saldo { get; private set; }
        public Agencia Agencia { get; private set; }
        public Cliente Cliente { get; private set; }

        public Conta(long numero, decimal saldo, Agencia agencia, Cliente cliente)
        {
            if (agencia == null)
            {
                throw new ArgumentException("Conta deve pertencer a uma agência.");
            }
            if (cliente == null)
            {
                throw new ArgumentException("Conta deve pertencer a um cliente.");
            }

            Numero = numero;
            Saldo = saldo;
            Agencia = agencia;
            Cliente = cliente;
        }

        public void Deposito(decimal valor)
        {
            if (valor <= 0)
            {
                throw new ArgumentException("Valor de depósito deve ser maior que zero.");
            }

            Saldo += valor;
        }

        public void Saque(decimal valor)
        {
            if (valor > Saldo)
            {
                throw new InvalidOperationException("Saldo insuficiente para realizar o saque.");
            }

            Saldo -= valor;
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{    public class Agencia
    {
        public int Numero { get; private set; }
        public string Nome { get; private set; }
        public string Telefone { get; private set; }

        public Agencia(int numero, string nome = "", string telefone = "")
        {
            if (numero <= 0)
            {
                throw new ArgumentException("Número da agência deve ser informado e maior que zero.");
            }

            Numero = numero;
            Nome = nome;
            Telefone = telefone;
        }
    }
}


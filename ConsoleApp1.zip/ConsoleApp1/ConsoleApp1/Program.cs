﻿using ConsoleApp1;

try
{
    Console.WriteLine("Informe os dados da Agência:");
    Console.Write("Número da Agência: ");
    int numeroAgencia = int.Parse(Console.ReadLine());

    Console.Write("Nome da Agência: ");
    string nomeAgencia = Console.ReadLine();

    Console.Write("Telefone da Agência: ");
    string telefoneAgencia = Console.ReadLine();

    var agencia = new Agencia(numeroAgencia, nomeAgencia, telefoneAgencia);


    Console.WriteLine("\nInforme os dados do Cliente:");
    Console.Write("Nome do Cliente: ");
    string nomeCliente = Console.ReadLine();

    Console.Write("CPF do Cliente: ");
    string cpfCliente = Console.ReadLine();

    var cliente = new Cliente(nomeCliente, cpfCliente);


    Console.WriteLine("\nInforme os dados da Conta:");
    Console.Write("Número da Conta: ");
    long numeroConta = long.Parse(Console.ReadLine());

    Console.Write("Saldo Inicial: ");
    decimal saldoInicial = decimal.Parse(Console.ReadLine());

    var conta = new Conta(numeroConta, saldoInicial, agencia, cliente);


    Console.WriteLine("\nDetalhes da Conta:");
    Console.WriteLine($"Conta Número: {conta.Numero}");
    Console.WriteLine($"Agência Número: {conta.Agencia.Numero}, Nome: {conta.Agencia.Nome}, Telefone: {conta.Agencia.Telefone}");
    Console.WriteLine($"Cliente Nome: {conta.Cliente.Nome}, CPF: {conta.Cliente.CPF}");
    Console.WriteLine($"Saldo Inicial: {conta.Saldo}");


    Console.Write("\nInforme o valor do saque: ");
    decimal valorSaque = decimal.Parse(Console.ReadLine());
    conta.Saque(valorSaque);
    Console.WriteLine($"Saldo após saque: {conta.Saldo}");
}
catch (Exception ex)
{
    Console.WriteLine($"Erro: {ex.Message}");
}
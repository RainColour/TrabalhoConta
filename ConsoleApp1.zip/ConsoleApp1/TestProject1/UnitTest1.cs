namespace TestProject1
{
    using ConsoleApp1;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    namespace ExemplosAulaTest
    {
        [TestClass]
        public class ContaTest
        {
            [TestMethod]
            public void TestDeposito()
            {
                long _numero = 123;
                decimal _saldoInicial = 1000;
                decimal _valorDeposito = 1000;
                decimal _saldoFinal = 2000;
                var agencia = new Agencia(1, "Agencia Central", "1234-5678");
                var cliente = new Cliente("Jo�o Silva", "123.456.789-00");
                var conta1 = new Conta(_numero, _saldoInicial, agencia, cliente);


                conta1.Deposito(_valorDeposito);


                Assert.AreEqual(_saldoFinal, conta1.Saldo);
            }

            [TestMethod]
            public void TestSaque()
            {

                long _numero = 123;
                decimal _saldoInicial = 1000;
                decimal _valorSaque = 500;
                decimal _saldoFinal = 500;
                var agencia = new Agencia(1, "Agencia Central", "1234-5678");
                var cliente = new Cliente("Jo�o Silva", "123.456.789-00");
                var conta1 = new Conta(_numero, _saldoInicial, agencia, cliente);


                conta1.Saque(_valorSaque);


                Assert.AreEqual(_saldoFinal, conta1.Saldo);
            }

            [TestMethod]
            [ExpectedException(typeof(InvalidOperationException))]
            public void TestSaqueSaldoInsuficiente()
            {

                long _numero = 123;
                decimal _saldoInicial = 1000;
                decimal _valorSaque = 1500;
                var agencia = new Agencia(1, "Agencia Central", "1234-5678");
                var cliente = new Cliente("Jo�o Silva", "123.456.789-00");
                var conta1 = new Conta(_numero, _saldoInicial, agencia, cliente);

                conta1.Saque(_valorSaque);

            }
        }
    }
}
